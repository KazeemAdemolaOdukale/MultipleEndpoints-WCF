﻿using System.Runtime.Serialization;

namespace StringServices
{
    [DataContract]
    public class CustomClass
    {
        [DataMember]
        public string Word { get; set; }

        [DataMember]
        public int Length { get; set; }

        public override string ToString()
        {
            return string.Format("{0,-20} {1,-2}", Word, Length);
        }
    }
}