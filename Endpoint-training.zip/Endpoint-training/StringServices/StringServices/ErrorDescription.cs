﻿namespace StringServices
{
    public class ErrorDescription
    {
        public int ErrorCode { get; set; }
        public string ErrorDesc { get; set; }
    }
}