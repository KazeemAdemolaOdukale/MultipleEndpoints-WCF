﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace StringServices
{
    public class StringService : IStringService
    {
        public List<string> ConvertToArray(string str)
        {
            if (!string.IsNullOrEmpty(str))
            {
                List<string> listWords = new List<string>(str.Split(' '));
                return listWords;
            }
            else
            {
                throw new FaultException<ErrorDescription>(new ErrorDescription { ErrorCode = 401, ErrorDesc = "input can not be null" });
            }
        }

        public string ConvertToUpperCase(string str)
        {
            if (!string.IsNullOrEmpty(str))
            {
                return str.ToUpper();
            }
            else
            {
                throw new FaultException<ErrorDescription>(new ErrorDescription { ErrorCode = 401, ErrorDesc = "input can not be null" });
            }
        }

        public int LengthOfString(string str)
        {
            if (!string.IsNullOrEmpty(str))
            {
                return str.Length;
            }
            else
            {
                throw new FaultException<ErrorDescription>(new ErrorDescription { ErrorCode = 401, ErrorDesc = "input can not be null" });
            }
        }

        public List<CustomClass> WordLengths(string str)
        {
            if (!string.IsNullOrEmpty(str))
            {
                List<CustomClass> customClass = new List<CustomClass>();
                List<string> customList = new List<string>(str.Split(' '));
                foreach (var item in customList)
                {
                    customClass.Add(new CustomClass { Word = item, Length = item.Length });
                }
                return customClass;
            }
            else
            {
                throw new FaultException<ErrorDescription>(new ErrorDescription { ErrorCode = 401, ErrorDesc = "input can not be null" });
            }
        }
    }
}
