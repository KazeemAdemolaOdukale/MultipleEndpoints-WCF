﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace StringServices
{
    [ServiceContract]
    public interface IStringService
    {
        [OperationContract]
        [FaultContract(typeof(ErrorDescription))]
        List<string> ConvertToArray(string str);

        [OperationContract]
        [FaultContract(typeof(ErrorDescription))]
        string ConvertToUpperCase(string str);

        [OperationContract]
        [FaultContract(typeof(ErrorDescription))]
        int LengthOfString(string str);

        [OperationContract]
        [FaultContract(typeof(ErrorDescription))]
        List<CustomClass> WordLengths(string str);
    }
}
