﻿using MyWcfClient.ServiceReference;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyWcfClient
{
    public partial class Form1 : Form
    {
        ServiceReference.StringServiceClient serClient = new ServiceReference.StringServiceClient("tcp");

        public Form1()
        {
            InitializeComponent();
            MyInitializations();
        }

        private void MyInitializations()
        {
            cmbMethods.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbMethods.Items.AddRange(Enum.GetNames(typeof(OperationMethods)));
            cmbMethods.SelectedIndex = (int)OperationMethods.ConvertToArray;
        }

        private enum OperationMethods
        {
            ConvertToArray,
            ConvertToUpperCase,
            LengthOfString,
            WordLengths
        }

        private void button1_Click(object sender, EventArgs e)
        {
            switch (cmbMethods.SelectedIndex)
            {
                case (int)OperationMethods.ConvertToArray:
                    lstOutput.Items.Clear();
                    ConvertToArray();
                    break;

                case (int)OperationMethods.ConvertToUpperCase:
                    lstOutput.Items.Clear();
                    ConvertToUpperCase();

                    break;
                case (int)OperationMethods.LengthOfString:
                    lstOutput.Items.Clear();
                    LengthOfString();
                    break;

                default:
                    lstOutput.Items.Clear();
                    WordLengths();
                    break;
            }
        }

        private void ConvertToArray()
        {
            try
            {
                lstOutput.Items.AddRange(serClient.ConvertToArray(txtString.Text));
            }
            catch (FaultException<ErrorDescription> faultEx)
            {
                ErrorMessageFaultException(faultEx);
            }
            catch (CommunicationException commEx)
            {
                ErrorMessageCommunicationException(commEx);
            }
        }

        private void ConvertToUpperCase()
        {
            try
            {
                lstOutput.Items.Add(serClient.ConvertToUpperCase(txtString.Text));
            }
            catch (FaultException<ErrorDescription> faultEx)
            {
                ErrorMessageFaultException(faultEx);
            }
            catch (CommunicationException commEx)
            {
                ErrorMessageCommunicationException(commEx);
            }
        }

        private void LengthOfString()
        {
            try
            {
                lstOutput.Items.Add(serClient.LengthOfString(txtString.Text));
            }
            catch (FaultException<ErrorDescription> faultEx)
            {
                ErrorMessageFaultException(faultEx);
            }
            catch (CommunicationException commEx)
            {
                ErrorMessageCommunicationException(commEx);
            }
        }

        private void WordLengths()
        {
            try
            {
                var outcome = serClient.WordLengths(txtString.Text);
                lstOutput.Items.Add(string.Format("{0,-15} {1,-2}", "Words", "Lengths"));
                foreach (var item in outcome)
                {
                    lstOutput.Items.Add(string.Format("{0,-15} {1,-2}", item.Word, item.Length));
                }
            }
            catch (FaultException<ErrorDescription> faultEx)
            {
                ErrorMessageFaultException(faultEx);
            }
            catch (CommunicationException commEx)
            {
                ErrorMessageCommunicationException(commEx);
            }            
        }

        private void cmbMethods_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbMethods.SelectedIndex == (int)OperationMethods.ConvertToArray)
            {
                lstOutput.Items.Clear();
                ConvertToArray();
            }
            else if (cmbMethods.SelectedIndex == (int)OperationMethods.ConvertToUpperCase)
            {
                lstOutput.Items.Clear();
                ConvertToUpperCase();
            }
            else if (cmbMethods.SelectedIndex == (int)OperationMethods.LengthOfString)
            {
                lstOutput.Items.Clear();
                LengthOfString();
            }
            else
            {
                lstOutput.Items.Clear();
                WordLengths();
            }
        }

        private void ErrorMessageFaultException(FaultException<ErrorDescription> faultException)
        {
            MessageBox.Show("Error " + faultException.Detail.ErrorCode + "   Error Description: " + faultException.Detail.ErrorDesc, "Fault Exception", MessageBoxButtons.OK);
            txtString.Focus();
        }

        private void ErrorMessageCommunicationException(CommunicationException commException)
        {
            MessageBox.Show("There was communication issue " + commException.Message + commException.StackTrace, "Communication Error", MessageBoxButtons.OK);
            txtString.Focus();
        }
    }
}
